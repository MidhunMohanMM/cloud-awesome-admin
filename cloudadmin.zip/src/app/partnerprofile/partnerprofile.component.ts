import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partnerprofile',
  templateUrl: './partnerprofile.component.html',
  styleUrls: ['./partnerprofile.component.css']
})
export class PartnerprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
