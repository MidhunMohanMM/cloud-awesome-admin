import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admineditprofile',
  templateUrl: './admineditprofile.component.html',
  styleUrls: ['./admineditprofile.component.css']
})
export class AdmineditprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
